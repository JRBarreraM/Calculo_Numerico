function miu = calcular_miu(A)
  miu=real(A(1,1))-1;