function y = phi(x)
  y=x(1);