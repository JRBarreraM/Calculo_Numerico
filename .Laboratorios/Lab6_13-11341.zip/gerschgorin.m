% C?rculos de Gerschgorin

% Funci�n que encuentra la cota de los autovalores de una matriz compleja
% (esto incluye tambi�n a las reales) de orden nxn.

% Entrada: A = Matriz

% Salida:  C = C�rculos de Gerschgorin

function C = gerschgorin(A)
    hold on
    D = diag(A);
    A = A - diag(D);
    colors = get(gca,'colororder');
    circle = exp(2*pi*1i*(0:32)/32);
    for k = 1:size(A,1)
       disc = D(k) + norm(A(k,:),1)*circle;
       c = colors(mod(k,length(colors))+1,:);
       plot(real(D(k)),imag(D(k)),'*','color',c)
       plot(real(disc),imag(disc),'-','color',c);
    end
    axis equal
    hold off
end
