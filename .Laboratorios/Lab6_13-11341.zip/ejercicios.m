% Autor: David Segura 13-11341

% Ejercicio 1

% Use el metodo de la potencia para calcular numericamente el autovalor
% de mayor magnitud de A y un autovector asociado para epsilon = 1, 
% 10?2, 10?4, 10?8.

% Epsilon=  1
clc,clear
A = [1 1 0; 0 1 1;0 1 1];
x = ones(3,1);
[autovector1,autovalor1,iteraciones1] = potencia(A,x,8000);

% Epsilon = 10^-2
A = [1 1 0; 0 1 10^(-2);0 10^(-2) 1];
[autovector2,autovalor2,iteraciones2] = potencia(A,x,8000);

% Epsilon = 10^-4
A = [1 1 0; 0 1 10^(-4);0 10^(-4) 1];
[autovector3,autovalor3,iteraciones3] = potencia(A,x,30000);

% Ejercicio 2

% Escriba una funcion en Matlab que reciba una matriz y dibuje sus 
% c?rculos de Gerschgorin usando un color distinto para cada circulo.

% Inciso A
grid on
A = [4 -1 0 0;-1 4 -1 0;-1 -1 4 0;1 0 -1 2+1i];
gerschgorin(A)

% Inciso B
A = [-4 0 1+1i 3;0 -4 2 1;1+1i 2 -2 0;3 1 0 -4i];
gerschgorin(A)




