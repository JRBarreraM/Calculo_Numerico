% Metodo de la Potencia

% Funci�n que aplica un m�todo iterativo que calcula sucesivas
% aproximaciones a los autovectores y autovalores de una matriz.

% Entrada: A = Matriz
%          x = vector
%          N = iteraciones m�ximas

% Salida:  x = autovector
%          r = autovalor
%          k = numero de iteraciones
function [x,r,k] = potencia(A,x,N)
    x = x/norm(x,inf);
    for k=1:1:N
        y = A*x;
        j = norm(x-(y/norm(y,inf)),inf);
        if j < 0.000000001
            r = y(1)/x(1);
            return
        end
        x = y/norm(y,inf);
    end
end
        

        