function [eqm] = ecuadraticomedio(f,y)
    n = length(f);
    y = y';
    eqm = sqrt(sum((y-f).^2)/n);
end