% Autor: David Segura #13-11341
% Laboratorio 7

% Pregunta 1
clc,clear
load data.mat
% Parte A
c5 = polyfit(xd,yd,5);
c15 = polyfit(xd,yd,15);
c20 = polyfit(xd,yd,20);
xp = linspace(0,8,52);
yp5 = polyval(c5,xd)';
yp15 = polyval(c15,xd)';
yp20 = polyval(c20,xd)';
errorc5 = ecuadraticomedio(yd,yp5);
errorc15 = ecuadraticomedio(yd,yp15);
errorc20 = ecuadraticomedio(yd,yp20);
% Parte B
subplot(2,2,1);
yp5 = polyval(c5,xp);
h = plot(xp,yp5,'r',xd,yd,'*');
title('Aproximaci�n de la funci�n con polinomio de grado 5')
grid on
xlabel('Tiempo')
ylabel('Temperatura')
legend(h,'Aproximaci�n v�a m�nimos cuadrados','Datos de la funci�n')
subplot(2,2,2);
yp15 = polyval(c15,xp);
g = plot(xp,yp15,'b',xd,yd,'*');
grid on
xlabel('Tiempo')
ylabel('Temperatura')
legend(g,'Aproximaci�n v�a m�nimos cuadrados','Datos de la funci�n')
title('Aproximaci�n de la funci�n con polinomio de grado 15')
subplot(2,2,[3,4]);
yp20 = polyval(c15,xp);
j = plot(xp,yp20,'g',xd,yd,'*');
grid on
xlabel('Tiempo')
ylabel('Temperatura')
legend(j,'Aproximaci�n v�a m�nimos cuadrados','Datos de la funci�n')
title('Aproximaci�n de la funci�n con polinomio de grado 20')
disp('Aproximacion de temperatura a los 4.5 minutos')
% Parte C
% La aproximacion se ajusta a los datos obtenidos experimentalmente. El
% error cuadratico medio indica que las aproximaciones son aceptables y que
% la mejor de ellas es la del polinomio de grado 20. Incluso la aproximacion
% con el polinomio de grado 5 aunque graficamente parece no ser ajustada
% el error cuadratico medio indica que si lo es.
% Al aproximar una funcion por el metodo de minimos cuadrados 
% se busca que este error sea muy peque�o, 
% de esta manera los datos que no estan incluidos en la tabla de datos 
% se pueden calcular de manera confiable. Pero se agarrar� el de grado 15
% ya que concuerda mas con la grafica.
y1545 = polyval(c15,4.5);
format long
disp(y1545)
disp('Aproximacion de temperatura a los 5 minutos')
y155 = polyval(c15,5);
format long
disp(y155)
disp('Aproximacion de temperatura a los 5.5 minutos')
y1555 = polyval(c15,5.5);
format long
disp(y1555)
disp('El tiempo en el cual la temperatura es de 36.612 grados es')
c15(16) = c15(16)-36.612;
raices = roots(c15);
% Se muestra la raiz del polinomio entre [0,8]. Se le resto al polinomio el
% valor de temperatura que queremos calcular. De esta forma el polinomio
% queda igualado a 0 y podemos conseguir sus raices.
disp(raices(8))


