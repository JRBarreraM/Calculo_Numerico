% Funci�n que aproxima el coseno con la funci�n recursiva de Taylor
function salida=cosrecursivo(ent1,ent2)
    % El �ltimo termino de la funcion recursiva.
    salida = (-1).^ent2;
    % Ciclo for para la recursividad de la funci�n recursiva
    % de Taylor dsde el valor introducido por el usuario
    % (ent2) hasta 1.
    for n=ent2:-1:1
        % Funcion recursiva de Taylor
        salida = ((salida.*(ent1.^2)) /((2.*n)*(2.*n -1))) + (-1).^(n - 1);
    end
end