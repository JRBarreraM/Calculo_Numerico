% Graficar desde 8*pi hasta 14*pi tomando puntos equispaciados
% con paso 0.01 de las funciones cos, cospolinomio y
% cosrecursivo con n=51
clc,clear
x = 8*pi:0.01:14*pi;
y = cospolinomio(x,51);
w = cosrecursivo(x,51);
z = cos(x);
% Grafica de la funci�n cospolinomio, cuyo color es azul
plot(x,y,'b')
hold on
% Grafica de la funcion cosrecursivo, cuyo color es rojo
plot(x,w,'r')
% Grafica de la funcion cos, cuyo color es verde
plot(x,z,'g')