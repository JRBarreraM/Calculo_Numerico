% Funci�n que aproxima al coseno por el polinomio de Taylor
function salida=cospolinomio(ent1,ent2)
    salida = 0;
    % Ciclo for para la sumatoria del polinomio de Taylor
    % de grado 2n dsde 0 hasta el valor introducido por
    % el usuario (ent2).
    for n=0:ent2
        % Polinomio de taylor de grado 2n
        salida =(-1).^n * (ent1.^(2*n))/factorial(2*n) + salida;
    end
end