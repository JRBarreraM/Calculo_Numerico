% Errores relativos

% Error relativo para cos(2) y cospolinomio(2,51)
error_relativo1=abs((cospolinomio(2,51)-cos(2))/cos(2))
x=sprintf('Error relativo para cospolinomio con x=2 es %d',error_relativo1)
display(x)

% Error relativo para cos(8) y cospolinomio(8,51)
error_relativo2=abs((cospolinomio(8,51)-cos(8))/cos(8))
y=sprintf('Error relativo para cospolinomio con x=8 es %d',error_relativo2)
display(y)

% Error relativo para cos(16) y cospolinomio(16,51)
error_relativo3=abs((cospolinomio(16,51)-cos(16))/cos(16))
z=sprintf('Error relativo para cospolinomio con x=16 es %d',error_relativo3)
display(z)

% Error relativo para cos(2) y cosrecursivo(2,51)
error_relativo4=abs((cosrecursivo(2,51)-cos(2))/cos(2))
a=sprintf('Error relativo para cosrecursivo con x=2 es %d',error_relativo4)
display(a)

% Error relativo para cos(8) y cosrecursivo(8,51)
error_relativo5=abs((cosrecursivo(8,51)-cos(8))/cos(8))
b=sprintf('Error relativo para cosrecursivo con x=8 es %d',error_relativo5)
display(b)

% Error relativo para cos(16) y cosrecursivo(16,51)
error_relativo6=abs((cosrecursivo(16,51)-cos(16))/cos(16))
c=sprintf('Error relativo para cosrecursivo con x=16 es %d',error_relativo6)
display(c)