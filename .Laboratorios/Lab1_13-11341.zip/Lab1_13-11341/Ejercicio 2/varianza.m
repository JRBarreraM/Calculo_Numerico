% Varianza de los n�meros 10000000000, 10000000001 y 10000000002 mediante
% la ecuaci�n (1)

V = 0 %Varianza
y = 0 
valores = [10000000000, 10000000001, 10000000002]
n = length(valores)
% Sumatoria de y
for i=1:n
    y = (1/n)*valores(i) + y;
end

% Sumatoria para conseguir la Varianza
for j=1:n
    V = (1/(n-1))*(valores(j)-y)^2 + V;
end

c=sprintf('La varianza de los n�meros 10000000000, 10000000001 y 10000000002 mediante la ecuaci�n (1) es %d',V)
display(c)

% Varianza de los n�meros 10000000000, 10000000001 y 10000000002 mediante
% la ecuaci�n (2)

V2 = 0 %Varianza
y2 = 0 
x2 = 0
% Sumatoria de y2
for i=1:n
    y2 = valores(i)^2 + y;
end

% Sumatoria de x2
for j=1:n
    x2 = valores(j)+x2;
end

V2= (y2-((x2^2)/n))/(n-1)
d=sprintf('La varianza de los n�meros 10000000000, 10000000001 y 10000000002 mediante la ecuaci�n (2) es %d',V2)
display(d)