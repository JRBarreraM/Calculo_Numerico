% Factorizaci�n LU de Crout

% Funci�n que aplica el m�todo de Factorizaci�n LU de Crout

% Entrada: a = Matriz
% Salidas: l = matriz triangular inferior
%          u = matriz triangular superior
function [l,u] = crout(a)
[n,m] = size(a);
l = zeros(n,n);
u = zeros(n,n) + eye(n,n);
for k = 1:n;
    suma1 = 0;
    for p = 1:n-1;
        suma1 = suma1 + l(k,p)*u(p,k);
    end
    l(k,k) = (a(k,k) - suma1)/u(k,k); 
    for j = k+1:n;
        suma2 = 0;
        for p = 1:k-1;
            suma2 = suma2 + l(k,p)*u(p,j);
        end
        u(k,j) = (a(k,j) - suma2)/l(k,k);
    end
    for i = k+1:n;
        suma3 = 0;
        for p = 1:k-1;
            suma3 = suma3 + l(i,p)*u(p,k);
        end
        l(i,k) = (a(i,k) - suma3)/u(k,k);
    end
end
end
            
            