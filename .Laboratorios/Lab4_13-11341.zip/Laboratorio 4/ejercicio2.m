% Ejercicio 2

% Autor: David Segura 13-11341

% Genere una matriz Y de tama�o 250x250 con entradas aleatorias en el
% intervalo [-5; 5]. Considere las matrices:

%           B = Y*Y'
%           A = B + (e - min(a))I

% donde a son los autovalores de B, e > 0 e I es la matriz identidad.
% Sea b = A*c donde c es el vector de tama�o 250 con entradas c(i) = (-1)^i
clc,clear
Y = (rand(250,250)-rand(250,250))*5;
B = Y * Y';
autovalor = min(eig(B));
I = eye(250,250);
c = zeros(250,1);
for i=1:250;
    c(i)=(-1)^i;
end

% (a) Muestre que A es una matriz sim�trica y positivo definida.
disp('-----Inciso (a)-----')
% Para mostrar que es simetrica veamos si la matriz A es igual a su
% traspuesta, para ello tomaremos cualquier valor de e, en este caso e = 2.

A = B + (2 - autovalor)*I;
disp('---�La matriz A es simetrica y definida positiva?---')
if A == A';
    disp('La matriz A es sim�trica')
else
    disp('No es sim�trica')
end

% Para mostrar que es definida positiva veremos si las determinantes de las
% submatrices cuadradas de la matriz A son positivas.

positiva = 1;
for i=1:250;
    if det(A(1:i,1:i)) > 0
        continue
    else
        positiva = 0;
        break
    end
end
if positiva == 1
    disp('La matriz A es definida positiva')
else
    disp('La matriz A no es definida positiva')
end

% (b) Resuelva el sistema de ecuaciones Ax = b para e = 10^?12, 10^?8 y
% 10^?4 usando la factorizaci�n LU de Crout y la factorizaci�n de Cholesky.
% Para cada m�todo calcule el tiempo CPU empleado al resolver el sistema de
% ecuaciones lineales (use el comando tic-toc).

disp('-----Inciso (b)-----')

% Para e = 10^-12
disp('--- e = 10^-12')
A = B + (10^(-12) - autovalor)*I;
b = A*c;
autovalorA = min(eig(A));
print = sprintf('Minimo autovalor: %s',autovalorA);
disp(print)
condicionA = norm(A,inf)*norm(inv(A),inf);
print = sprintf('N�mero condici�n de A en norma infinito: %s',condicionA);
disp(print)
tic; % Crout
[L, U] = crout(A);
solucion1 = sustadelante(L,b);
solucion2 = sustatras(U,solucion1);
tiempofinal=toc;
disp('1) La soluci�n al sistema Ax = b con Fact LU de Crout es')
disp(solucion2)
print = sprintf('1) Tiempo de ejecuci�n: %s',tiempofinal);
disp(print)
error = errorrelativo(solucion2,c);
print = sprintf('1) Error Relativo: %s',error);
disp(print)
tic; % Cholesky
L = cholesky(A);
solucion1 = sustadelante(L,b);
solucion2 = sustatras(L',solucion1);
tiempofinal=toc;
disp('2) La soluci�n al sistema Ax = b con Fact LU de Cholesky es')
disp(solucion2)
print = sprintf('2) Tiempo de ejecuci�n: %s',tiempofinal);
disp(print)
error = errorrelativo(solucion2,c);
print = sprintf('2) Error Relativo: %s',error);
disp(print)

% Para e = 10^-8
disp('--- e = 10^-8')
A = B + (10^(-8) - autovalor)*I;
b = A*c;
autovalorA = min(eig(A));
print = sprintf('Minimo autovalor: %s',autovalorA);
disp(print)
condicionA = norm(A,inf)*norm(inv(A),inf);
print = sprintf('N�mero condici�n de A en norma infinito: %s',condicionA);
disp(print)
tic; % Crout
[L, U] = crout(A);
solucion1 = sustadelante(L,b);
solucion2 = sustatras(U,solucion1);
tiempofinal=toc;
disp('1) La soluci�n al sistema Ax = b con Fact LU de Crout es')
disp(solucion2)
print = sprintf('1) Tiempo de ejecuci�n: %s',tiempofinal);
disp(print)
error = errorrelativo(solucion2,c);
print = sprintf('1) Error Relativo: %s',error);
disp(print)
tic; % Cholesky
L = cholesky(A);
solucion1 = sustadelante(L,b);
solucion2 = sustatras(L',solucion1);
tiempofinal=toc;
disp('2) La soluci�n al sistema Ax = b con Fact LU de Cholesky es')
disp(solucion2)
print = sprintf('2) Tiempo de ejecuci�n: %s',tiempofinal);
disp(print)
error = errorrelativo(solucion2,c);
print = sprintf('2) Error Relativo: %s',error);
disp(print)

% Para e = 10^-4
disp('--- e = 10^-4')
A = B + (10^(-4) - autovalor)*I;
b = A*c;
autovalorA = min(eig(A));
print = sprintf('Minimo autovalor: %s',autovalorA);
disp(print)
condicionA = norm(A,inf)*norm(inv(A),inf);
print = sprintf('N�mero condici�n de A en norma infinito: %s',condicionA);
disp(print)
tic; % Crout
[L, U] = crout(A);
solucion1 = sustadelante(L,b);
solucion2 = sustatras(U,solucion1);
tiempofinal=toc;
disp('1) La soluci�n al sistema Ax = b con Fact LU de Crout es')
disp(solucion2)
print = sprintf('1) Tiempo de ejecuci�n: %s',tiempofinal);
disp(print)
error = errorrelativo(solucion2,c);
print = sprintf('1) Error Relativo: %s',error);
disp(print)
tic; % Cholesky
L = cholesky(A);
solucion1 = sustadelante(L,b);
solucion2 = sustatras(L',solucion1);
tiempofinal=toc;
disp('2) La soluci�n al sistema Ax = b con Fact LU de Cholesky es')
disp(solucion2)
print = sprintf('2) Tiempo de ejecuci�n: %s',tiempofinal);
disp(print)
error = errorrelativo(solucion2,c);
print = sprintf('2) Error Relativo: %s',error);
disp(print)