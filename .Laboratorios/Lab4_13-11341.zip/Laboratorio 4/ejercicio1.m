% Ejercicio 1

% Autor: David Segura 13-11341

% Sea A = (a[i][j]), con a[i][j] = min (i,j) si i != j y a[i][j] = -500000
% si i = j para i,j = 1,2,...,1000. Asimismo, b = (b[i]) con b[i] = i para
% i = 1,2,...,1000.

% (a) Resuelva el sistema Ax = b utilizando eliminaci�n Gaussiana sin 
% pivoteo programado por Ud. en Matlab, y anote el tiempo de CPU.

clc,clear
A = zeros(1000,1000);
b = zeros(1000,1);
for i=1:1000;
    b(i)= i;
    for j=1:1000;
        if i==j;
            A(i,j)= -500000;
        else
            A(i,j)= min(i,j);
        end
    end
end

tic;
[matriz, vector]=gauss(A,b,0);
solucion = sustatras(matriz,vector);
tiempofinal = toc;
disp('La soluci�n al sistema Ax = b con eliminaci�n Gaussiana sin pivoteo es')
disp(solucion)
disp('Tiempo de ejecuci�n')
disp(tiempofinal)

% (b) Resuelva el sistema Ax = b utilizando la descomposici�n LU de Crout de 
% la matriz A. Anote el tiempo total de CPU utilizado. �Qu� concluye? Use
% el programa de descomposici�n LU de Crout general programado por Ud. en
% Matlab.

tic;
[L, U] = crout(A);
solucion1 = sustadelante(L,b);
solucion2 = sustatras(U,solucion1);
tiempofinal=toc;
disp('La soluci�n al sistema Ax = b con Fact LU de Crout es')
disp(solucion)
disp('Tiempo de ejecuci�n')
disp(tiempofinal)