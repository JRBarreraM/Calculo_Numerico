% Factorizaci�n LU de Cholesky

% Funci�n que aplica el m�todo de factorizaci�n LU de Cholesky para
% resolver un sistema lineal de ecuaciones.

% Entrada: a = Matriz
% Salida:  l = Matriz triangular inferior
function [l] = cholesky(a)

n = size(a);
for k = 1:n;
    suma1 = 0;
    for s = 1:k-1;
        suma1 = suma1 + (l(k,s))^2;
    end
    l(k,k) = (a(k,k) - suma1)^(1/2);
    for i = k+1:n;
        suma1 = 0;
        for s = 1:k-1;
            suma1 = suma1 + l(i,s)*l(k,s);
        end
        l(i,k) = (a(i,k) - suma1)/l(k,k);
    end
end
end
            
    
