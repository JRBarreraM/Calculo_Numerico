% Ejercicio 3

% Autor: David Segura #13-11341

% Los sistemas de ecuaciones lineales se pueden usar para modelar las
% concentraciones (variables desconocidas c en [g/m3]) en una serie de
% reactores acoplados como funci�n de la cantidad de masa inyectada a cada
% reactor (variables del lado derecho b en [g/d�a]). El modelo para
% nuestro ejemplo es:

%       10c1 + 7c2 - 2c3 - 5c4 = 2283
%       12c1 - 5c2 + 7c3 + 11c4 = 5755
%       5c1 + 6c2 + 12c3 - 8c4 = 6046
%       4c1 + 1c2 - 3c3 + 13c4 = 4465

% (1) Determine el equilibro de los reactores utilizando solamente la
% factorizaci�n LU de A y los algoritmos de sustituci�n hacia adelante y 
% atr�s.

A = [10,7,-2,-5;12,-5,7,11;5,6,12,-8;4,1,-3,13];
b = [2283;5755;6046;4465];

[L, U] = matrizlu(A);
solucion1 = sustadelante(L,b);
solucion2 = sustatras(U,solucion1);
u = sprintf('---Equilibrio de los reactores usando factorizaci�n LU---');
disp(u)
disp(solucion2)

% (2) Determine la inversa de la matriz A utilizando la factorizaci�n
% construida en el punto anterior. Asegure que estim� la inversa
% correctamente, verifique que inv(A)*A = I.

Matriz_Inv = invermatriz(A);
u = sprintf('---Matriz inversa de A usando factorizaci�n LU---');
disp(u)
disp(Matriz_Inv)

verificar = Matriz_Inv * A;
u = sprintf('---Verificaci�n de inv(A)*A = I ---');
disp(u)
disp(verificar)

% (3) Utilizando la inversa estime el equilibrio de los reactores.

[L1, U1] = matrizlu(Matriz_Inv);
solucion3 = sustadelante(L1,b);
solucion4 = sustatras(U1,solucion3);
u = sprintf('---Equilibrio de los reactores usando Matriz Inversa de A---');
disp(u)
disp(solucion4)

