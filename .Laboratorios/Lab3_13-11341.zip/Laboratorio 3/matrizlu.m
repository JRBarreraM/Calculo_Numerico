% Matrices Lower y Upper de una Matriz
% Funci�n que aplica la descomposici�n LU y devuelve ambas matrices
% Entradas:	A = Matriz a descomponer

% Salida: lower = Matriz triangular inferior
%         upper = Matriz triangular superior
function [lower,upper] = matrizlu(A)
    [n m] = size(A);
    for k = 2:n;
        for i = k:n;
            A(i,k-1) = A(i,k-1)/A(k-1,k-1);
            for j = k:n
                A(i,j) = A(i,j)-((A(i,k-1).*A(k-1,j)));
            end
        end
    end
    upper = triu(A,0);
    lower = tril(A,-1);
    lower = lower + eye(n);
end

