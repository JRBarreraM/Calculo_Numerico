% Matriz inversa mediante LU
% Funci�n que consigue la matriz inversa usando la descomposici�n LU
% Entradas:	A = Matriz a descomponer e invertir

% Salida: Ainversa = Matriz inversa de A

function [Ainversa] = invermatriz(A)
    [n m] = size(A);
    contador = 1;
    melemental = zeros(n,1);
    while contador <= n;
        if contador == 1;
            [L,U] = matrizlu(A);
        end
        melemental(contador,1) = 1;
        solucion1 = sustadelante(L,melemental);
        solution = sustatras(U,solucion1);
        if contador == 1;
            Ainversa = solution;
        else
            Ainversa = [Ainversa,solution];
        end
        melemental(contador,1) = 0;
        contador = contador + 1;
    end
end