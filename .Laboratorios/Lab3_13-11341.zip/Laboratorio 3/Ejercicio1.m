% Ejercicio 1
% Autor: David Segura #13-11341

% Utilizando la factorizaci�n LU, estime las inversas de las siguientes 
% matrices A1 y A2. Implemente en MATLAB los algoritmos de sustituci�n
% hacia adelante y hacia atr�s, y util�celos para hallar las inversas.
% Verifique su resultado usando A* inv(A) = I. Escoja una m�trica y reporte
% la norma de la diferencia entre A* inv(A) y la identidad. Compare su
% diferencia calculada con la diferencia estimada a trav�s del comando 
% inv(A)*A. De una explicaci�n a los resultados obtenidos.

A1 = [8,2,2;3,5,1;1,9,3];
A2 = [7,3,1;9,5,4;1,1,4];

MatrizInv_A1 = invermatriz(A1);
MatrizInv_A2 = invermatriz(A2);

u = sprintf('---Matriz Inversa de A1 Usando Descomposici�n LU---');
disp(u);
disp(MatrizInv_A1);

u = sprintf('---Matriz Inversa de A2 Usando Descomposici�n LU---');
disp(u);
disp(MatrizInv_A2);

u = sprintf('---Verificaci�n de A1 * A1 inversa---');
disp(u);
identidad1 = MatrizInv_A1*A1;
disp(identidad1);

u = sprintf('---Verificaci�n de A2 * A2 inversa---');
disp(u);
identidad2 = MatrizInv_A2*A2;
disp(identidad2);

u = sprintf('---Error Relativo de la diferencia de A1 * A1 inversa y la identidad usando LU---');
disp(u);
identidad = eye(3);
error1 = errorrelativo(identidad1,identidad);
disp(error1)

u = sprintf('---Error Relativo de la diferencia de A2 * A2 inversa y la identidad usando LU---');
disp(u);
error2 = errorrelativo(identidad2,identidad);
disp(error2)

u = sprintf('---Error Relativo de la diferencia de A1 * inv(A1) y la identidad usando inv---');
disp(u);
identidadnormal1 = A1 * inv(A1);
error3 = errorrelativo(identidadnormal1,identidad);
disp(error3)

u = sprintf('---Error Relativo de la diferencia de A2 * inv(A2) y la identidad usando inv---');
disp(u);
identidadnormal2 = A2 * inv(A2);
error4 = errorrelativo(identidadnormal2,identidad);
disp(error4)