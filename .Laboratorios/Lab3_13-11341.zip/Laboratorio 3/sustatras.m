% Sustituci�n hacia atr�s
% Funci�n que aplica el metodo de sustituci�n hacia atras para
% resolver la matriz triangular superior con su vector
% solucion
% Entradas:	C = Matriz triangular superior
% 			d = Vector solucion de la matriz C
% Salida: solucion = solucion del sistema de ecuaciones lineal
function solucion = sustatras(C,d)
    [n m]=size(C);
    x = zeros(n,1);
    for i = n:-1:1
        sum = 0;
        for j=i+1:n
            sum = sum + C(i,j)*x(j);
        end
        x(i,1) = (d(i) - sum)/C(i,i);
    end
    solucion = x;
end
  
    