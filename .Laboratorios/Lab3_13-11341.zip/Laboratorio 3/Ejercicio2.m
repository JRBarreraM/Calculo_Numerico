% Ejercicio 2

% Autor: David Segura #13-11341

A = [90,1,2,3,4;1,90,2,3,4;1,2,90,3,4;1,2,3,90,4;1,2,3,4,90];
b = [1;2;3;4;5];
c = [1,2,3,4,5];
d = [11;-3;8;7;9];

% (1). Halle la factorizaci�n LU de la matriz A.

[L, U] = matrizlu(A);
u = sprintf('---Matriz L---');
disp(u)
disp(L)
u = sprintf('---Matriz U---');
disp(u)
disp(U)

% (2). Resuelva los sistemas de ecuaciones Ax = b, y'A = c y Ax = d usando 
% las matrices L y U obtenidas en el item anterior.

u = sprintf('---USANDO LA FUNCI�N CREADA POR MI---');
disp(u)
solucion1 = sustadelante(L,b);
solucion2 = sustatras(U,solucion1);
u = sprintf('---Resoluci�n de Ax = b ---');
disp(u)
disp(solucion2)

solucion3 = sustadelante(L,c);
solucion4 = sustatras(U,solucion3);
u = sprintf('---Resoluci�n de y� A = c ---');
disp(u)
disp(solucion4)

solucion5 = sustadelante(L,d);
solucion6 = sustatras(U,solucion5);
u = sprintf('---Resoluci�n de Ax = d ---');
disp(u)
disp(solucion6)

% (3) Repita el ejercicio utilizando el comando de Matlab [L,U,P]=lu(A)
% para hallar la factorizaci�n.

[L1,U1,P1] = lu(A);
u = sprintf('---USANDO LA FUNCI�N DE MATLAB---');
disp(u)
solucion1 = sustadelante(L1,b);
solucion2 = sustatras(U1,solucion1);
u = sprintf('---Resoluci�n de Ax = b ---');
disp(u)
disp(solucion2)

solucion3 = sustadelante(L1,c);
solucion4 = sustatras(U1,solucion3);
u = sprintf('---Resoluci�n de y� A = c ---');
disp(u)
disp(solucion4)

solucion5 = sustadelante(L1,d);
solucion6 = sustatras(U1,solucion5);
u = sprintf('---Resoluci�n de Ax = d ---');
disp(u)
disp(solucion6)