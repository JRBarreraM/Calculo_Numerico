% f(x) = (x*sin(x))/(x^2+1)

% Entrada: x = valor a evaluar

% Salida : y = resultado de la funcion

function [y] = funcion(x)
    y = (x*sin(x))/(x^2+1);
end