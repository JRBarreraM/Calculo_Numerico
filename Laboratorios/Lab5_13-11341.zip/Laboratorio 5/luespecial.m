% Factorizaci�n LU para Matrices Especiales

% Funci�n que aplica el m�todo de factorizaci�n LU modificado para matrices
% especiales.

% Entrada: A = Matriz
% Salida:  l = Matriz triangular inferior

function [l, u] = luespecial(A)
    [n, m] = size(A);
    l = zeros(m,n);
    u = zeros(m,n)+eye(m,n);
    l(1,1) = A(1,1);
    u(1,2) = A(1,2)/l(1,1);
    for i = 2:n-1;
        l(i,i-1) = A(i,i-1);
        l(i,i) = A(i,i) - (l(i,i-1)*u(i-1,i));
        u(i,i+1) = A(i,i+1)/l(i,i);
    end
    l(n,n-1) = A(n,n-1);
    l(n,n) = A(n,n) - (l(n,n-1)*u(n-1,n));
    whos
end