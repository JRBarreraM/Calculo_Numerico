% Creaci�n de Matriz tridiagonal

% Funci�n que crea una matriz tridiagonal de tama�o n con los valores que
% el usuario indique.

% Entrada: n = tama�o de la matriz
%          di = valor para la diagonal inferior
%          dp = valor para la diagonal principal
%          ds = valor para la diagonal superior

% Salida:  A = Matriz tridiagonal

function A = tridiagonal(n,di,dp,ds)
    A = full(gallery('tridiag',n,di,dp,ds));
end