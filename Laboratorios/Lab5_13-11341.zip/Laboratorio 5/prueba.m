% N = 20

print = sprintf('---------- N = 20 ----------');
disp(print)

n = 20;
h = 1/n;
g = 1/h^2;
A = g*tridiagonal(n,-1,2,-1);
b = zeros(n,1);
tic; % LU
[L, U] = luespecial(A);
solucion1 = sustadelante(L,b);
solucion2 = sustatras(U,solucion1);
tiempofinal=toc;
print = sprintf('Tiempo de ejecuci�n de LU: %s',tiempofinal);
disp(print)

tic; % SOR
[x, res] = relajacion(A,b,1);
tiempofinal=toc;
print = sprintf('Tiempo de ejecuci�n de Relajacion: %s',tiempofinal);
disp(print)
print = sprintf('Norma: %s',res);
disp(print)

tic; % Richardson
[x, res] = richardson(A,b);
tiempofinal=toc;
print = sprintf('Tiempo de ejecuci�n de Richardson: %s',tiempofinal);
disp(print)
print = sprintf('Norma: %s',res);
disp(print)

% N = 50

print = sprintf('---------- N = 50 ----------');
disp(print)

n = 50;
h = 1/n;
g = 1/h^2;
A = g*tridiagonal(n,-1,2,-1);
b = zeros(n,1);
tic; % LU
[L, U] = luespecial(A);
solucion1 = sustadelante(L,b);
solucion2 = sustatras(U,solucion1);
tiempofinal=toc;
print = sprintf('Tiempo de ejecuci�n de LU: %s',tiempofinal);
disp(print)

tic; % SOR
[x, res] = relajacion(A,b,1);
tiempofinal=toc;
print = sprintf('Tiempo de ejecuci�n de Relajacion: %s',tiempofinal);
disp(print)
print = sprintf('Norma: %s',res);
disp(print)

tic; % Richardson
[x, res] = richardson(A,b);
tiempofinal=toc;
print = sprintf('Tiempo de ejecuci�n de Richardson: %s',tiempofinal);
disp(print)
print = sprintf('Norma: %s',res);
disp(print)

% N = 100

print = sprintf('---------- N = 100 ----------');
disp(print)

n = 100;
h = 1/n;
g = 1/h^2;
A = g*tridiagonal(n,-1,2,-1);
b = zeros(n,1);
tic; % LU
[L, U] = luespecial(A);
solucion1 = sustadelante(L,b);
solucion2 = sustatras(U,solucion1);
tiempofinal=toc;
print = sprintf('Tiempo de ejecuci�n de LU: %s',tiempofinal);
disp(print)

tic; % SOR
[x, res] = relajacion(A,b,1);
tiempofinal=toc;
print = sprintf('Tiempo de ejecuci�n de Relajacion: %s',tiempofinal);
disp(print)
print = sprintf('Norma: %s',res);
disp(print)

tic; % Richardson
[x, res] = richardson(A,b);
tiempofinal=toc;
print = sprintf('Tiempo de ejecuci�n de Richardson: %s',tiempofinal);
disp(print)
print = sprintf('Norma: %s',res);
disp(print)

% N = 500

print = sprintf('---------- N = 500 ----------');
disp(print)

n = 500;
h = 1/n;
g = 1/h^2;
A = g*tridiagonal(n,-1,2,-1);
b = zeros(n,1);
tic; % LU
[L, U] = luespecial(A);
solucion1 = sustadelante(L,b);
solucion2 = sustatras(U,solucion1);
tiempofinal=toc;
print = sprintf('Tiempo de ejecuci�n de LU: %s',tiempofinal);
disp(print)

tic; % SOR
[x, res] = relajacion(A,b,1);
tiempofinal=toc;
print = sprintf('Tiempo de ejecuci�n de Relajacion: %s',tiempofinal);
disp(print)
print = sprintf('Norma: %s',res);
disp(print)

tic; % Richardson
[x, res] = richardson(A,b);
tiempofinal=toc;
print = sprintf('Tiempo de ejecuci�n de Richardson: %s',tiempofinal);
disp(print)
print = sprintf('Norma: %s',res);
disp(print)