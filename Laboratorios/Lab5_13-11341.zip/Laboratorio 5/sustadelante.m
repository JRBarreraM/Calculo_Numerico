% Sustituci�n hacia adelante
% Funci�n que aplica el metodo de sustituci�n hacia adelante para
% resolver la matriz triangular inferior con su vector
% solucion
% Entradas:	C = Matriz triangular superior
% 			d = Vector solucion de la matriz C
% Salida: solucion = solucion del sistema de ecuaciones lineal
function solucion = sustadelante(A,b)
    [n m] = size(A);
    x = zeros(n,1);
    for i = 1:n;
        sum = 0;
        for j=1:i;
            sum = sum + (A(i,j).*x(j));
        end
        x(i,1) = (b(i)-sum)./A(i,i);
    end
    solucion = x;
end

