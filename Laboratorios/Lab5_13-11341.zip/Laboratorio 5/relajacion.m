% M�todo SOR

% Funci�n que aplica el m�todo iterativo de relajaci�n para resolver
% sistemas de ecuaciones lineales de tipo (D-E-F)x = b siendo D la diagonal
% de A, -E el tri�ngulo inferior y -F el tri�ngulo superior.

% Entrada: A = Matriz
%          b = Vector solucion
%          w = acelerador
% Salida:  x = vector de incognitas
%          res = norma infinito del vector residual

function [x,res] = relajacion(A,b,w)
    [n, m] = size(A);
    x = zeros(n,1);
    x0=x;
    e = 10^-5;
    maxit = 1000;
    k = 0;
    D = diag(diag(A));
    E = -tril(A,-1);
    F = -triu(A,+1);
    res = norm (A*x0 - b,inf);
    
    while res > e && k<maxit
        k = k + 1;
        x = (D-w*E)\(w*F*x0+(1-w)*D*x0+w*b);
        res = norm(A*x-b,inf);
        x0 = x;
    end
    whos
end
        