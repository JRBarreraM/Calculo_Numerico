% M�todo Richardson

% Funci�n que aplica el m�todo iterativo de Richardson para resolver
% sistemas de ecuaciones lineales de tipo (M - N)x = b donde M es la matriz
% identidad.

% Entrada: A = Matriz
%          b = vector solucion
% Salida:  x = vector de incognitas
%          norma = norma infinito del vector residual

function [x,norma] = richardson(A,b)
    [n, m] = size(A);
    x = zeros(n,1);
    e = 10^-5;
    maxit = 1000;
    r = zeros(n,1);
    for k = 1:maxit
        for i = 1:n
            sum = 0;
            for j = 1:n
                sum = A(i,j)*x(j) + sum;
            end
            r(i) = b(i) - sum;
        end
        norma_r = abs(r(1));
        for i = 2:n
            s = abs(r(i));
            if s > norma_r
                norma_r = s;
            end
        end
        if norma_r < e
            norma = norma_r;
            break
        end
        for i = 1:n
            x(i) = x(i) + r(i);
        end
    end
    norma = norma_r;
    whos
end
    