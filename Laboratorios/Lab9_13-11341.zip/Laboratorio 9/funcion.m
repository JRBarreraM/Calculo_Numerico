% FUNCION A EVALUAR

% Funcion a evaluar en este laboratorio

% Entrada: x = valor a evaluar

% Salida:  y = imagen de x

function [y] = funcion(x)
    y = (x*sin(x))/(x^2+1);
end
